const productos = [{
        id: 1,
        denominacion: "carnes frías",
        comentario: "Auténtico, gourmet carnes cocinadas y vajilla fina de comedor con botella de vino, vasos y tablas de cortar en un banco de madera rústica",
        foto: "carnes.jpg"
    },
    {
        id: 2,
        denominacion: "desayunos",
        comentario: "Auténtico, gourmet carnes cocinadas y vajilla fina de comedor con botella de vino, vasos y tablas de cortar en un banco de madera rústica",
        foto: "desayuno.jpg"
    },
    {
        id: 3,
        denominacion: "tomates",
        comentario: "Vista de primer plano de verduras orgánicas maduras frescas en el mercado de agricultores ",
        foto: "tomates.jpg"
    },
    {
        id: 4,
        denominacion: "huevos",
        comentario: "Composición con variedad de productos comestibles como carne y productos lácteos",
        foto: "huevos.jpg"
    },
    {
        id: 5,
        denominacion: "embutidos",
        comentario: "Surtido de deliciosas carnes delicatessen en tabla de madera",
        foto: "embutidos.jpg"
    },
    {
        id: 6,
        denominacion: "lacteos",
        comentario: "La leche en mesa de madera con las vacas en el fondo ",
        foto: "lacteos.jpg"
    },
    {
        id: 7,
        denominacion: "quesos",
        comentario: "Estilo tradicional de las tazas de queso artesanales",
        foto: "quesos.jpg"
    }
];