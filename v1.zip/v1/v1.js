window.onload = function () {

    // Referencias y manejadores de evento de elementos estáticos
    // Botones
    let botones = document.querySelectorAll("button");
    botones[0].addEventListener("click", ponSeleccionados);
    botones[1].addEventListener("click", analizarValores);

    // Secciones
    let seccionElementos = document.querySelector(".elementos");
    let seccionInforme = document.querySelector(".informe");

    // Manejador de evento elementos seleccionados
    function ponSeleccionados() {
        // Variable para texto HTML
        let textoHTML = "";

        // Referencia a checked
        let checkeados = document.querySelectorAll(".seleccion input[type=checkbox]:checked");

        // Iteramos por array -> modeList
        for (const elemento of checkeados) {
            // Texto de etiqueta del elemento
            let etiqueta = document.querySelector(`.seleccion label[for=${elemento.id}]`);

            // Generamos cadena HTML aprovechando los valores de los atributos del elemento tratado
            textoHTML += `
            <article>
                <label for="${elemento.id}">${etiqueta.textContent}</label>
                <input type="${elemento.value}" id="${elemento.id}">
            </article>
            `;
        }

        // Poenmos elementos en su sección y ponemos color de borde
        seccionElementos.innerHTML = textoHTML;
        seccionElementos.style.borderColor = "#853400";
    }

    function analizarValores() {
        // Referencias a elementos creados en .elementos
        let elementos = document.querySelectorAll(".elementos input");

        // Variable para generar frase. Global a nivel de función
        let fraseParcial = "";

        // Recorrido de elementos
        for (const elemento of elementos) {
            // Procesamos condiciones en una estructura condicional para actuar en función del elemento tratado. Evaluamos el valor del id lo que nos dará el tipo del elemento en cuanto a lo que tenemos que realizar con él
            switch (elemento.id) {
                // El nombre y apelldios tienen limitaciones en longitud <45
                case "nombre":
                    let nombre = (elemento.value.length > 45) ? "<b>se ha introducido un nombre incorrecto</b>" : elemento.value;
                    fraseParcial = `una persona que se llama ${nombre}`
                    break;
                case "fecha":
                    // Convertimos la fecha de YYYY-MM-DD a DD-MM-AAAA
                    let arrayFN = elemento.value.split("-");
                    let fNacimiento = `${arrayFN[2]}-${arrayFN[1]}-${arrayFN[0]}`
                    if (fraseParcial == "")
                        fraseParcial = `una persona que ha nacido el ${fNacimiento}`
                    else
                        fraseParcial += ` y  ha nacido el ${fNacimiento}`;
                    break;
                // La dirección tienen limitaciones en longitud <55
                case "direccion":
                    let direccion = (elemento.value.length > 55) ? "<b>se ha introducido una dirección incorrecta</b>" : elemento.value;
                    if (fraseParcial == "")
                        fraseParcial = `una persona que vive en ${direccion}`
                    else
                        fraseParcial += ` y vive en ${direccion}`;
                    break;
                // El código postal tiene dos limitaciones: provincia (dos primeros dígitos) y longitud =5
                case "cp":
                    // Comprobamos si el código postal está en los aceptados y tiene 5 dígitos
                    let cpValidadoMsg = comprobarCP(elemento.value);

                    if (fraseParcial == "")
                        fraseParcial = `una persona cuyo código postal es ${cpValidadoMsg}`
                    else
                        fraseParcial += ` y código postal ${cpValidadoMsg}`;
                    break;
            }
        }
        ponInforme(fraseParcial);
    }

    function comprobarCP(cp) {
        // Códigos válidos
        let cpAceptados = [15, 27, 32, 33, 39];

        // Cadena en caso de cp no válido
        let error = "<b>el código postal introducido no es correcto</b>";

        // Comprobación código provincia. Hay que convertirlo a número porque array es numérico
        let codigoProvincia = parseInt(cp.slice(0, 2));

        if (!cpAceptados.includes(codigoProvincia)) return error;

        // Comprobamos que la longitud es 5
        let valorCP = (cp.length != 5) ? error : cp;
        return valorCP;

    }

    function ponInforme(fraseElementos) {
        // Creamos frase completa. Parte inicial fija y la construida en función de los elementos
        let frase = `La información introducida en los elementos creados corresponde a ${fraseElementos}`;

        // colocamos frase en sección informe com innerHTML para procesar las etiquetas HTML y ponemos color de borde
        seccionInforme.innerHTML = frase;
        seccionInforme.style.borderColor = "#853400";
    }
}